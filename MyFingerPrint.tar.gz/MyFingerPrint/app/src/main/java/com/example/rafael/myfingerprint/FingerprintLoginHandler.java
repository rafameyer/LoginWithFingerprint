package com.example.rafael.myfingerprint;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by rafael on 10/08/17.
 */

@RequiresApi(api = Build.VERSION_CODES.M)
public class FingerprintLoginHandler extends FingerprintManager.AuthenticationCallback {
    private Context context;

    // Constructor
    public FingerprintLoginHandler(Context mContext) {
        context = mContext;
    }

    public void startAuth(FingerprintManager manager, FingerprintManager.CryptoObject cryptoObject) {
        CancellationSignal cancellationSignal = new CancellationSignal();
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        manager.authenticate(cryptoObject, cancellationSignal, 0, this, null);
    }

    @Override
    public void onAuthenticationError(int errMsgId, CharSequence errString) {
        this.update("Fingerprint Authentication error\n" + errString);
    }

    @Override
    public void onAuthenticationHelp(int helpMsgId, CharSequence helpString) {
        this.update("Fingerprint Authentication help\n" + helpString);
    }

    @Override
    public void onAuthenticationFailed() {
        this.update("Fingerprint Authentication failed.");
    }

    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
        final SharedPreferences preferences = context.getSharedPreferences("USER", Context.MODE_PRIVATE);
        String usuario = preferences.getString("USUARIO", null);

        if (usuario != null && usuario.length() > 0){
            Intent intent = new Intent(context, MenuActivity.class);
            context.startActivity(intent);
        }
    }

    private void update(String e){
        Toast.makeText(context, e, Toast.LENGTH_SHORT).show();
    }
}
